USE techfactory_db;

CREATE TABLE